import React from 'react'
import FormInput from '../FormInput1/Forminput1'
import Button from '../../components/Button/Button'
import Select from 'react-select'

import { DROPDOWN_1 } from '../../services/demoData'

function SmartContract() {
  state = {
    user: {
      firstName: '',
    },
    errors: {},
    submitted: false,
  }

  handleChange = event => {
    const { user } = this.state
    user[event.target.name] = event.target.value
    this.setState({ user })
  }

  onSubmit = () => {
    const {
      user: { firstName },
    } = this.state
    let err = {}

    if (!firstName) {
      err.firstName = 'Enter your First Name!'
    }

    this.setState({ errors: err }, () => {
      if (Object.getOwnPropertyNames(this.state.errors).length === 0) {
        this.setState({ submitted: true })
      }
    })
  }

  return (
    <div>
      <div className="modal">
        <div className="modal-head">
          <button className="btn-clone"></button>
          <div className="head-content"></div>
        </div>
        <div className="modal-body">
          <div className="body-content">
            <FormInput
              label="First Name"
              name="firstName"
              type="text"
              value={state.user.firstName}
              onChange={this.handleChange}
              placeholder=""
              error={state.errors.firstName}
              required
              // className="input input-item"
            />
          </div>
        </div>
      </div>
    </div>
  )
}

export default SmartContract
