import React from 'react'
import PropTypes from 'prop-types'

import './Table.scss'

const Table = ({
  tableData,
  headingColumns,
  title,
  tableFor,
  breakOn = 'medium',
  handleOnClick,
}) => {
  let tableClass = 'table-container__table'

  if (breakOn === 'small') {
    tableClass += ' table-container__table--break-sm'
  } else if (breakOn === 'medium') {
    tableClass += ' table-container__table--break-md'
  } else if (breakOn === 'large') {
    tableClass += ' table-container__table--break-lg'
  }

  const data = tableData.map((row, index) => {
    let rowData = []
    let i = 0
    for (const key in row) {
      if (
        key.toUpperCase() ===
        headingColumns[i].toUpperCase().split(' ').join('')
      ) {
        if (tableFor === 'marketplace1') {
          if (key === 'quantity') {
            rowData.push({
              key: headingColumns[i],
              val: 'up to ' + row[key] + ' ' + row['unit'],
            })
          } else if (key === 'perUnit') {
            rowData.push({
              key: headingColumns[i],
              val: row[key] + '/' + row['unit'],
            })
          } else {
            rowData.push({
              key: headingColumns[i],
              val: row[key],
            })
          }
        } else if (
          tableFor === 'marketplace2' ||
          tableFor === 'contracts2' ||
          tableFor === 'contracts1'
        ) {
          if (key === 'quantity') {
            rowData.push({
              key: headingColumns[i],
              val: row[key] + ' ' + row['unit'],
            })
          } else if (key === 'perUnit') {
            rowData.push({
              key: headingColumns[i],
              val: row[key] + '/' + row['unit'],
            })
          } else {
            rowData.push({
              key: headingColumns[i],
              val: row[key],
            })
          }
        } else {
          rowData.push({
            key: headingColumns[i],
            val: row[key],
          })
        }

        i++
      }
    }

    return (
      <tr className="dt-row" key={index}>
        {rowData.map((data, index) => (
          <td className="dt-cell" key={index} data-heading={data.key}>
            {data.val}
          </td>
        ))}
      </tr>
    )
  })

  return (
    <div className="table-container">
      <div className="table-container__title">
        <h2>{title}</h2>
      </div>
      <table className={tableClass}>
        <thead className="dt-head">
          <tr className="dt-head-row">
            {headingColumns.map((col, index) => (
              <th className="dt-head-cell" key={index}>
                {col}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="dt-body" onClick={handleOnClick}>
          {data}
        </tbody>
      </table>
    </div>
  )
}

Table.propTypes = {
  tableData: PropTypes.arrayOf(PropTypes.object).isRequired,
  headingColumns: PropTypes.arrayOf(PropTypes.string).isRequired,
  title: PropTypes.string.isRequired,
  tableFor: PropTypes.string.isRequired,
  breakOn: PropTypes.oneOf(['small', 'medium', 'large']),
  handleOnClick: PropTypes.func,
}

export default Table
