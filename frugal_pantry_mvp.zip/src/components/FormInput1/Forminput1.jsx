import React from 'react'
import PropTypes from 'prop-types'

import './FormInput1.scss'
const FormInput1 = ({
  name,
  type,
  placeholder,
  onChange,
  className,
  value,
  error,
  children,
  label,
  labelClassName,
  ...props
}) => {
  return (
    <React.Fragment>
      <div className="input-container">
        <label className={labelClassName} htmlFor={name}>
          {label}
        </label>
        <div className="input-row">
          <input
            id={name}
            name={name}
            type={type}
            placeholder={placeholder}
            onChange={onChange}
            value={value}
            className={className}
            style={error && { border: 'solid 1px red' }}
          />
          {error && <span>{error}</span>}
        </div>
      </div>
    </React.Fragment>
  )
}

FormInput1.defaultProps = {
  type: 'text',
  className: '',
}

FormInput1.propTypes = {
  name: PropTypes.string.isRequired,

  placeholder: PropTypes.string.isRequired,
  type: PropTypes.oneOf(['text', 'number', 'password', 'email']),
  className: PropTypes.string,
  value: PropTypes.any,
  onChange: PropTypes.func.isRequired,
}

export default FormInput1
