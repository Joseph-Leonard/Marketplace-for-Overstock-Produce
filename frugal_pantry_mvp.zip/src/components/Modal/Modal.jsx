import React, { useState } from 'react'

import {
  DATA_ITEM_DROPDOWN,
  DATA_QUALITY_DROPDOWN,
  DATA_UNIT_DROPDOWN,
} from '../../services/demoData'

import Button from '../../components/Button/Button'
import Modal1 from '../../components/Modal/Modal1'
import FormInput from '../../components/FormInput1/Forminput1'
import Select from 'react-select'

import './Modal.scss'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'

const Modal = ({ closeModal, children }) => {
  const [status1, setStatus1] = useState(false)
  const [status2, setStatus2] = useState(false)
  const [status3, setStatus3] = useState(false)
  const [status4, setStatus4] = useState(false)

  const [quantity, setQuantity] = useState(0)
  const [pricePerUnit, setPricePerUnit] = useState(0)
  const [totalPrice, setTotalPrice] = useState(0)

  const closeicon = () => (
    <>
      <div className="modal-header">
        <FontAwesomeIcon
          icon="times"
          onClick={() => closeModal()}
          className="modal-icons"
        />
        <div className="modal-head-link">
          <Button
            handleClick={() => setStatus1(true)}
            type="button"
            label="Buy"
            className="btn btn-buy"
          />
          {status1 && (
            <Modal1 closeModal={() => setStatus1(false)} heading="Buy">
              <div className="modal-body bsd-modal-body">
                <div className="react-select-container">
                  <label className="react-select-label">Item</label>

                  <Select
                    id="item"
                    className="react-select"
                    classNamePrefix="react-select"
                    options={DATA_ITEM_DROPDOWN}
                  />
                </div>

                <div className="react-select-container">
                  <label className="react-select-label">Quality</label>

                  <Select
                    id="quality"
                    className="react-select"
                    classNamePrefix="react-select"
                    options={DATA_QUALITY_DROPDOWN}
                  />
                </div>

                <FormInput
                  label="Quantity"
                  name="quantity"
                  type="number"
                  value={quantity}
                  // onChange={handleChange}
                  placeholder=""
                  required
                />

                <div className="react-select-container">
                  <label className="react-select-label">Unit</label>

                  <Select
                    id="unit"
                    className="react-select"
                    classNamePrefix="react-select"
                    options={DATA_UNIT_DROPDOWN}
                  />
                </div>

                <FormInput
                  label="Price Per Unit"
                  name="pricePerUnit"
                  type="number"
                  value={pricePerUnit}
                  // onChange={handleChange}
                  placeholder=""
                  required
                />

                <FormInput
                  label="Total"
                  name="total"
                  type="number"
                  value={totalPrice}
                  // onChange={handleChange}
                  placeholder=""
                  required
                />

                <div className="btn-link">
                  <div className="conditions-container">
                    {status4 && (
                      <Modal1
                        closeModal={() => setStatus4(false)}
                        modalWidth="464px"
                        heading="Terms of Service"
                        modalType="Notification"
                      >
                        <div className="modal-body  notification-modal-body">
                          This is an pre-alpha stage product.
                          <br /> All bids and sales are with test ada. <br />{' '}
                          Please do not send real ada to wallets.
                        </div>
                      </Modal1>
                    )}
                    <input
                      type="checkbox"
                      name="termsConditions"
                      id="termsConditions"
                      className="checkbox"
                    />
                    <span className="terms-onditions-text">
                      I agree the{' '}
                      <span onClick={() => setStatus4(true)}>
                        terms and conditions
                      </span>
                    </span>
                  </div>

                  <Button
                    type="submit"
                    label="Accept"
                    className="btn-account-accept"
                    // handleClick={onSubmit}
                  />

                  <Button
                    type="submit"
                    label="Cancel"
                    className="btn-account-cancel"
                    // handleClick={onSubmit}
                  />
                </div>
              </div>
            </Modal1>
          )}
          /
          <Button
            handleClick={() => setStatus2(true)}
            type="button"
            label="Sell"
            className="btn btn-sell"
          />
          {status2 && (
            <Modal1 closeModal={() => setStatus2(false)} heading="Sell">
              <div className="modal-body bsd-modal-body">
                <div className="react-select-container">
                  <label className="react-select-label">Item</label>

                  <Select
                    id="item"
                    className="react-select"
                    classNamePrefix="react-select"
                    options={DATA_ITEM_DROPDOWN}
                  />
                </div>

                <FormInput
                  label="Quantity"
                  name="quantity"
                  type="number"
                  value={quantity}
                  // onChange={handleChange}
                  placeholder=""
                  required
                />

                <div className="react-select-container">
                  <label className="react-select-label">Unit</label>

                  <Select
                    id="unit"
                    className="react-select"
                    classNamePrefix="react-select"
                    options={DATA_UNIT_DROPDOWN}
                  />
                </div>

                <FormInput
                  label="Price Per Unit"
                  name="pricePerUnit"
                  type="number"
                  value={pricePerUnit}
                  // onChange={handleChange}
                  placeholder=""
                  required
                />

                <FormInput
                  label="Total"
                  name="total"
                  type="number"
                  value={totalPrice}
                  // onChange={handleChange}
                  placeholder=""
                  required
                />

                <div className="btn-link">
                  <div className="conditions-container">
                    {status4 && (
                      <Modal1
                        closeModal={() => setStatus4(false)}
                        modalWidth="464px"
                        heading="Terms of Service"
                        modalType="Notification"
                      >
                        <div className="modal-body  notification-modal-body">
                          This is an pre-alpha stage product.
                          <br /> All bids and sales are with test ada. <br />{' '}
                          Please do not send real ada to wallets.
                        </div>
                      </Modal1>
                    )}
                    <input
                      type="checkbox"
                      name="termsConditions"
                      id="termsConditions"
                      className="checkbox"
                    />
                    <span className="terms-onditions-text">
                      I agree the{' '}
                      <span onClick={() => setStatus4(true)}>
                        terms and conditions
                      </span>
                    </span>
                  </div>

                  <Button
                    type="submit"
                    label="Accept"
                    className="btn-account-accept"
                    // handleClick={onSubmit}
                  />

                  <Button
                    type="submit"
                    label="Cancel"
                    className="btn-account-cancel"
                    // handleClick={onSubmit}
                  />
                </div>
              </div>
            </Modal1>
          )}
          /
          <Button
            handleClick={() => setStatus3(true)}
            type="button"
            label="Donate"
            className="btn btn-donate"
          />
          {status3 && (
            <Modal1 closeModal={() => setStatus3(false)} heading="Donate">
              <div className="modal-body bsd-modal-body">
                <div className="react-select-container">
                  <label className="react-select-label">Item</label>

                  <Select
                    id="item"
                    className="react-select"
                    classNamePrefix="react-select"
                    options={DATA_ITEM_DROPDOWN}
                  />
                </div>

                <FormInput
                  label="Quantity"
                  name="quantity"
                  type="number"
                  value={quantity}
                  // onChange={handleChange}
                  placeholder=""
                  required
                />

                <div className="react-select-container">
                  <label className="react-select-label">Unit</label>

                  <Select
                    id="unit"
                    className="react-select"
                    classNamePrefix="react-select"
                    options={DATA_UNIT_DROPDOWN}
                  />
                </div>

                <div className="btn-link">
                  <div className="conditions-container">
                    {status4 && (
                      <Modal1
                        closeModal={() => setStatus4(false)}
                        modalWidth="464px"
                        heading="Terms of Service"
                        modalType="Notification"
                      >
                        <div className="modal-body  notification-modal-body">
                          This is an pre-alpha stage product.
                          <br /> All bids and sales are with test ada. <br />{' '}
                          Please do not send real ada to wallets.
                        </div>
                      </Modal1>
                    )}
                    <input
                      type="checkbox"
                      name="termsConditions"
                      id="termsConditions"
                      className="checkbox"
                    />
                    <span className="terms-onditions-text">
                      I agree the{' '}
                      <span onClick={() => setStatus4(true)}>
                        terms and conditions
                      </span>
                    </span>
                  </div>

                  <Button
                    type="submit"
                    label="Accept"
                    className="btn-account-accept"
                    // handleClick={onSubmit}
                  />

                  <Button
                    type="submit"
                    label="Cancel"
                    className="btn-account-cancel"
                    // handleClick={onSubmit}
                  />
                </div>
              </div>
            </Modal1>
          )}
        </div>
      </div>
    </>
  )

  return (
    <div className="overlay">
      <div className="content">
        {closeicon()}
        {children}
      </div>
    </div>
  )
}

export default Modal
