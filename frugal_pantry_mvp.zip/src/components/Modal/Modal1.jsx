import React from 'react'
import './Modal1.scss'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'

const Modal1 = ({ closeModal, modalWidth, children, heading, modalType }) => {
  const closeicon = () => (
    <>
      <div className="modal-header">
        <FontAwesomeIcon
          icon="times"
          onClick={() => closeModal()}
          className="modal-icons"
        />
        {modalType === 'Notification' && (
          <div
            style={{ position: 'absolute', left: '160px' }}
            className="modal-head-link-notify"
          >
            {heading && <h4>{heading}</h4>}
          </div>
        )}
        {!modalType && (
          <div className="modal-head-link">{heading && <h4>{heading}</h4>}</div>
        )}
      </div>
    </>
  )

  return (
    <div className="overlay">
      <div style={{ width: modalWidth }} className="content">
        {closeicon()}

        {children}
      </div>
    </div>
  )
}

export default Modal1
