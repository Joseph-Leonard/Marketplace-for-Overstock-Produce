import React from 'react'
import { NavLink } from 'react-router-dom'

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import './Navbar.scss'

const Navbar = () => {
  return (
    <nav className="navbar">
      <span className="navbar-toggle" id="js-navbar-toggle">
        <FontAwesomeIcon icon="bars" />
        {/* <FontAwesomeIcon icon={['fas', 'coffee']} /> */}
      </span>
      <a className="logo">logo</a>

      <ul className="main-nav" id="js-menu">
        <li>
          <NavLink className="route-Link" to="/" exact>
            Home
          </NavLink>
        </li>
        <li>
          <NavLink className="route-Link" to="/inventory">
            Inventory
          </NavLink>
        </li>
        <li>
          <NavLink className="route-Link" to="/marketplace">
            Marketplace
          </NavLink>
        </li>
        <li>
          <NavLink className="route-Link" to="/contracts">
            Contracts
          </NavLink>
        </li>
        <li>
          <NavLink className="route-Link" to="/account">
            Account
          </NavLink>
        </li>
        <li>
          <NavLink className="route-Link" to="/help">
            Help
          </NavLink>
        </li>
        <li>
          <NavLink className="route-Link" to="/login">
            Login
          </NavLink>
        </li>
        <li>
          <NavLink className="route-Link" to="/sign-up">
            Sign Up
          </NavLink>
        </li>
      </ul>
    </nav>
  )
}

export default Navbar
