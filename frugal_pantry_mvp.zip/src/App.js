import React from 'react'
import { Switch, Route } from 'react-router-dom'

import WelcomePage from './pages/Welcome/WelcomePage'
import InventoryPage from './pages/Inventory/InventoryPage'
import MarketplacePage from './pages/Marketplace/MarketplacePage'
import ContractsPage from './pages/Contracts/ContractsPage'
import AccountPage from './pages/Account/AccountPage'
import HelpPage from './pages/Help/HelpPage'
import LoginPage from './pages/Login/Login'
import SignUpPage from './pages/SignUp/SignUpPage'

import './components/FontAwesome/FontAwesomeIcon'
import './App.css'

function App() {
  return (
    <Switch>
      <Route path="/inventory" component={InventoryPage} />
      <Route path="/marketplace" component={MarketplacePage} />
      <Route path="/contracts" component={ContractsPage} />
      <Route path="/account" component={AccountPage} />
      <Route path="/help" component={HelpPage} />
      <Route path="/sign-up" component={SignUpPage} />
      <Route path="/welcome" component={WelcomePage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/" component={LoginPage} exact />
    </Switch>
  )
}

export default App
