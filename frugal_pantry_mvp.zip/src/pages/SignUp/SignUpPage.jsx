import React, { Component } from 'react'
import Button from '../../components/Button/Button'
import FormInput from '../../components/FormInput1/Forminput1'
import Modal1 from '../../components/Modal/Modal1'
import Select from 'react-select'

import {
  DATA_COMPANY_TYPE_DROPDOWN,
  DATA_COUNTRY_DROPDOWN,
  DATA_STATE_DROPDOWN,
} from '../../services/demoData'

import './SignUpPage.scss'

export class SignUpPage extends Component {
  state = {
    termServiceModalOpen: false,
    user: {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      companyName: '',
      companyType: '',
      address: '',
      postal: '',
      city: '',
      country: '',
      state: '',
      userName: '',
      password: '',
      repeatPassword: '',
    },
    errors: {},
    submitted: false,
  }
  handleTermServiceModalStatus = () => {
    this.setState({ termServiceModalOpen: !this.state.termServiceModalOpen })
  }
  handleChange = event => {
    const { user } = this.state
    user[event.target.name] = event.target.value
    this.setState({ user })
  }

  onSubmit = () => {
    const {
      user: { firstName, lastName },
    } = this.state
    let err = {}

    if (!firstName) {
      err.firstName = 'Enter your First Name!'
    }

    if (!lastName) {
      err.lastName = 'Enter your last Name!'
    }

    this.setState({ errors: err }, () => {
      if (Object.getOwnPropertyNames(this.state.errors).length === 0) {
        this.setState({ submitted: true })
      }
    })
  }

  render() {
    const {
      submitted,
      errors,
      user: {
        firstName,
        lastName,
        email,
        phone,
        companyName,

        address,
        postal,
        city,

        userName,
        password,
        repeatPassword,
      },
    } = this.state
    return (
      <div className="signup-form-container">
        <form className="signup-form">
          {submitted ? (
            <p className="signup-welcome-text">Welcome onboard, {firstName}!</p>
          ) : (
            <React.Fragment>
              <h3 className="signup-text">Sign Up</h3>

              <FormInput
                label="First Name"
                name="firstName"
                type="text"
                value={firstName}
                onChange={this.handleChange}
                placeholder=""
                error={errors.firstName}
                required
                // className="input input-item"
              />

              <FormInput
                label="Last Name"
                name="lastName"
                type="text"
                value={lastName}
                onChange={this.handleChange}
                placeholder=""
                error={errors.lastName}
                required
                // className="input input-item"
              />

              <FormInput
                label="Email"
                name="email"
                type="email"
                value={email}
                onChange={this.handleChange}
                placeholder=""
                error={errors.email}
                // className="input input-item"
                required
              />

              <FormInput
                label="Phone"
                name="phone"
                type="text"
                value={phone}
                onChange={this.handleChange}
                placeholder=""
                error={errors.phone}
                // className="input input-item"
                required
              />

              <FormInput
                label="Company Name"
                name="companyName"
                type="text"
                value={companyName}
                onChange={this.handleChange}
                placeholder=""
                error={errors.companyName}
                // className="input input-item"
                required
              />
              <div className="react-select-container">
                <label className="react-select-label">Company Type</label>

                <Select
                  id="companyType"
                  className="react-select"
                  classNamePrefix="react-select"
                  options={DATA_COMPANY_TYPE_DROPDOWN}
                />
              </div>

              <FormInput
                label="Address"
                name="address"
                type="text"
                value={address}
                onChange={this.handleChange}
                placeholder=""
                error={errors.address}
                // className="input input-item"
                required
              />

              <FormInput
                label="Zip/Postal"
                name="postal"
                type="text"
                value={postal}
                onChange={this.handleChange}
                placeholder=""
                error={errors.postal}
                // className="input input-item"
                required
              />

              <FormInput
                label="City"
                name="city"
                type="text"
                value={city}
                onChange={this.handleChange}
                placeholder=""
                error={errors.city}
                // className="input input-item"
                required
              />
              <div className="react-select-container">
                <label className="react-select-label">Country</label>

                <Select
                  id="country"
                  className="react-select"
                  classNamePrefix="react-select"
                  options={DATA_COUNTRY_DROPDOWN}
                />
              </div>

              <div className="react-select-container">
                <label className="react-select-label">State/Province</label>

                <Select
                  id="state"
                  className="react-select"
                  classNamePrefix="react-select"
                  options={DATA_STATE_DROPDOWN}
                />
              </div>

              <div className="rular"></div>

              <FormInput
                label="Username"
                name="userName"
                type="text"
                value={userName}
                onChange={this.handleChange}
                placeholder=""
                error={errors.userName}
                // className="input input-item"
                required
              />

              <FormInput
                label="Password"
                name="password"
                type="password"
                value={password}
                onChange={this.handleChange}
                placeholder=""
                error={errors.password}
                // className="input input-item"
                required
              />

              <FormInput
                label="Repeat Password"
                name="repeatPassword"
                type="password"
                value={repeatPassword}
                onChange={this.handleChange}
                placeholder=""
                error={errors.repeatPassword}
                // className="input input-item"
                required
              />

              <div className="conditions-container">
                {this.state.termServiceModalOpen && (
                  <Modal1
                    closeModal={this.handleTermServiceModalStatus}
                    modalWidth="464px"
                    heading="Terms of Service"
                    modalType="Notification"
                  >
                    <div className="modal-body  notification-modal-body">
                      This is an pre-alpha stage product.
                      <br /> All bids and sales are with test ada. <br /> Please
                      do not send real ada to wallets.
                    </div>
                  </Modal1>
                )}

                <input
                  type="checkbox"
                  name="termsConditions"
                  id="termsConditions"
                  className="checkbox"
                />
                <span className="terms-onditions-text">
                  I agree the{' '}
                  <span onClick={this.handleTermServiceModalStatus}>
                    terms and conditions
                  </span>
                </span>
              </div>

              <div className="btn-link">
                <span></span>
                <Button
                  type="submit"
                  label="Sign Up"
                  className="btn-signup"
                  handleClick={this.onSubmit}
                />
                <span>Sign In</span>
              </div>

              {/* <Link className="route-Link" to="/sign-up">
                  {' '}
                </Link> */}
            </React.Fragment>
          )}
        </form>
      </div>
    )
  }
}

export default SignUpPage
