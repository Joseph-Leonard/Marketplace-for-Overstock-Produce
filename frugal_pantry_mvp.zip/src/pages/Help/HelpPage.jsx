import React, { Component } from 'react'
import PropTypes from 'prop-types'

import FormInput from '../../components/FormInput1/Forminput1'
import Navbar from '../../components/Navbar/Navbar'
import Button from '../../components/Button/Button'

import './HelpPage.scss'
export class HelpPage extends Component {
  static propTypes = {}
  state = {
    user: {
      userName: '',
      password: '',
      repeatPassword: '',
    },
    errors: {},
    submitted: false,
  }

  handleChange = event => {
    const { user } = this.state
    user[event.target.name] = event.target.value
    this.setState({ user })
  }

  onSubmit = () => {
    const {
      user: { userName, password, repeatPassword },
    } = this.state
    let err = {}

    if (!userName) {
      err.userName = 'Enter User Name!'
    }

    if (!password) {
      err.password = 'Enter your password!'
    }

    if (!repeatPassword) {
      err.repeatPassword = 'Enter your password!'
    }

    this.setState({ errors: err }, () => {
      if (Object.getOwnPropertyNames(this.state.errors).length === 0) {
        this.setState({ submitted: true })
      }
    })
  }

  render() {
    const {
      submitted,
      errors,
      user: { userName, password, repeatPassword },
    } = this.state
    return (
      <React.Fragment>
        <Navbar />

        <div className="help-card">
          <div className="card-header">
            <div className="card-title">
              <h3>Help</h3>
              <hr />
            </div>
          </div>
          <div className="card-body">
            <div className="content-container">
              <div className="help-description">
                <p>
                  This is an pre-alpha stage product all bids and sales are with
                  test ada.
                  <br />
                  <br />
                  Please do not send real ada to wallets.
                </p>
              </div>
              <div className="contact">
                <h5>Contact 1</h5>
                <div className="contat-details">
                  <p>
                    Bob has (x) ada <br />
                    Bob wants (x) of an item <br />
                    Bob will pay (x) per unit of that item <br />
                    <br />
                    Alice has (y) of that item <br />
                    Alice will pay said price <br />
                    <br />
                    Send Bob’s Ada to Alice; Send Alice item quantity Bob
                  </p>
                </div>
              </div>

              <div className="contact">
                <h5>Contact 2</h5>
                <div className="contat-details">
                  <p>
                    Alice has (x) of that item <br />
                    Alice wants (x) of Ada per unit of that item <br />
                    <br />
                    Bob has (x) ada <br />
                    Bob wants (x) of an item <br />
                    Bob will pay (x) per unit of that item <br />
                    <br />
                    Send Bob’s Ada to Alice; Send Alice item quantity Bob
                  </p>
                </div>
              </div>

              <div className="contact">
                <h5>Contact 3</h5>
                <div className="contat-details">
                  <p>
                    Alice has (x) of that item <br />
                    Alice wants to Donate (x) of that item <br />
                    <br />
                    Bob is an NGO and has (x) ada <br />
                    Bob wants (x) of an item <br />
                    Bob will take (x) per unit of that item <br />
                    <br />
                    Send Bob’s Transaction Cost to Alice; Send Alice item
                    quantity Bob
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="card-footer"></div>
        </div>

        <div className="help-card">
          <div className="card-header">
            <div className="card-title">
              <h3>Delete Account</h3>
              <hr />
            </div>
          </div>
          <div className="card-body">
            <div className="delete-account-container">
              <section>
                <FormInput
                  label="Username"
                  name="userName"
                  type="text"
                  value={userName}
                  onChange={this.handleChange}
                  placeholder=""
                  error={errors.userName}
                  // className="input input-item"
                  required
                />

                <FormInput
                  label="Password"
                  name="password"
                  type="password"
                  value={password}
                  onChange={this.handleChange}
                  placeholder=""
                  error={errors.password}
                  // className="input input-item"
                  required
                />

                <FormInput
                  label="Repeat Password"
                  name="repeatPassword"
                  type="password"
                  value={repeatPassword}
                  onChange={this.handleChange}
                  placeholder=""
                  error={errors.repeatPassword}
                  // className="input input-item"
                  required
                />

                <div className="btn-link">
                  <Button
                    type="submit"
                    label="Confirm Deletion"
                    className="btn-account"
                    handleClick={this.onSubmit}
                  />
                  <a>
                    {/* <FontAwesomeIcon icon="fa" /> */}
                    Cancel
                  </a>
                </div>
              </section>
            </div>
          </div>
          <div className="card-footer"></div>
        </div>
      </React.Fragment>
    )
  }
}

export default HelpPage
