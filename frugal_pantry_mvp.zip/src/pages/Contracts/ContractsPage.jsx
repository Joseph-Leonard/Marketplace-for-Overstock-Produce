import React, { Component } from 'react'

import { DATA_CONTRACTS_TABLE_1 } from '../../services/demoData'
import { DATA_CONTRACTS_TABLE_2 } from '../../services/demoData'
import {
  DATA_ITEM_DROPDOWN,
  DATA_UNIT_DROPDOWN,
  DATA_QUALITY_DROPDOWN,
} from '../../services/demoData'

import WithNavbar from '../../layout/WithNavbar'
import Button from '../../components/Button/Button'
import Table from '../../components/DataTable/Table'
import Modal from '../../components/Modal/Modal'
import Modal1 from '../../components/Modal/Modal1'
import FormInput from '../../components/FormInput1/Forminput1'
import Select from 'react-select'

import './ContractsPage.scss'

export class ContractsPage extends Component {
  state = {
    modalOpen: false,
    buyingModalOpen: false,
    sellingModalOpen: false,
    termServiceModalOpen: false,
    congratsModalOpen: false,
    user: {
      item: '',
      companyName: '',
      companyType: '',
      address: '',
      postal: '',
      city: '',
      state: '',
      details: '',
      country: '',
      quantity1: '',
      quantity: '',
      pricePerUnit: '',
      price: '',
      qtyPrice: '',
      total: '',
    },
    errors: {},
    submitted: false,
  }

  handleStatus = () => {
    this.setState({ modalOpen: !this.state.modalOpen })
  }

  handleBuyingClick = () => {
    this.setState({ buyingModalOpen: !this.state.buyingModalOpen })
  }

  handleSellingClick = () => {
    this.setState({ sellingModalOpen: !this.state.sellingModalOpen })
  }

  handleTermServiceModalStatus = () => {
    this.setState({ termServiceModalOpen: !this.state.termServiceModalOpen })
  }

  handleCongratsModalStatus = () => {
    console.log('fghjhgdhfgds')
    this.setState({ congratsModalOpen: !this.state.congratsModalOpen })
  }

  handleChange = event => {
    const { user } = this.state
    user[event.target.name] = event.target.value
    this.setState({ user })
  }

  onSubmit = () => {
    const {
      user: { quantity, pricePerUnit },
    } = this.state
    let err = {}

    if (!quantity) {
      err.quantity = 'Quantity is missing!'
    }

    if (!pricePerUnit) {
      err.pricePerUnit = 'Price per unit is missing!'
    }

    this.setState({ errors: err }, () => {
      if (Object.getOwnPropertyNames(this.state.errors).length === 0) {
        this.setState({ submitted: true })
      }
    })
  }

  render() {
    const {
      errors,
      user: {
        item,
        companyName,
        companyType,
        address,
        postal,
        city,
        state,
        country,
        quantity,
        quantity1,

        price,
        pricePerUnit,
        qtyPrice,
        total,
      },
    } = this.state

    return (
      <WithNavbar>
        <div className="card">
          <div className="card-header">
            <div className="card-title">
              <h3>Contracts</h3>
              <hr />
            </div>
          </div>
          <div className="card-body">
            <div className="heading-container">
              <span className="heading-text">Open Contracts</span>

              {this.state.modalOpen && (
                <Modal closeModal={this.handleStatus}>
                  <div className="modal-body contracts-modal-body">
                    <div className="react-select-container">
                      <label className="react-select-label">Item</label>

                      <Select
                        id="item"
                        className="react-select"
                        classNamePrefix="react-select"
                        options={DATA_ITEM_DROPDOWN}
                      />
                    </div>

                    <div className="react-select-container">
                      <label className="react-select-label">Quality</label>

                      <Select
                        id="quality"
                        className="react-select"
                        classNamePrefix="react-select"
                        options={DATA_QUALITY_DROPDOWN}
                      />
                    </div>

                    <FormInput
                      label="Quantity"
                      name="quantity"
                      type="number"
                      value={quantity}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.quantity}
                      required
                    />

                    <div className="react-select-container">
                      <label className="react-select-label">Unit</label>

                      <Select
                        id="unit"
                        className="react-select"
                        classNamePrefix="react-select"
                        options={DATA_UNIT_DROPDOWN}
                      />
                    </div>

                    <FormInput
                      label="Price Per Unit"
                      name="pricePerUnit"
                      type="number"
                      value={pricePerUnit}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.pricePerUnit}
                      required
                    />

                    <FormInput
                      label="Total"
                      name="total"
                      type="number"
                      value={total}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.total}
                      required
                    />

                    <div className="btn-link">
                      <div className="conditions-container">
                        {this.state.termServiceModalOpen && (
                          <Modal1
                            closeModal={this.handleTermServiceModalStatus}
                            modalWidth="464px"
                            heading="Terms of Service"
                            modalType="Notification"
                          >
                            <div className="modal-body  notification-modal-body">
                              This is an pre-alpha stage product.
                              <br /> All bids and sales are with test ada.{' '}
                              <br /> Please do not send real ada to wallets.
                            </div>
                          </Modal1>
                        )}

                        <input
                          type="checkbox"
                          name="termsConditions"
                          id="termsConditions"
                          className="checkbox"
                        />
                        <span className="terms-onditions-text">
                          I agree the{' '}
                          <span onClick={this.handleTermServiceModalStatus}>
                            terms and conditions
                          </span>
                        </span>
                      </div>

                      <Button
                        type="submit"
                        label="Accept"
                        className="btn-account-accept"
                      />

                      <Button
                        type="submit"
                        label="Cancel"
                        className="btn-account-cancel"
                        handleClick={this.onSubmit}
                      />
                    </div>
                  </div>
                </Modal>
              )}

              {this.state.buyingModalOpen && (
                <Modal1 closeModal={this.handleBuyingClick} heading="Buy">
                  <div className="modal-body buying-modal-body">
                    <FormInput
                      label="Item"
                      name="item"
                      type="text"
                      value={item}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.quantity}
                      required
                    />

                    <div className="rular-row">
                      <hr />
                    </div>

                    <FormInput
                      label="Company Name"
                      name="companyName"
                      type="text"
                      value={companyName}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.companyName}
                      // className="input input-item"
                      required
                    />

                    <FormInput
                      label="Company Type"
                      name="companyType"
                      type="text"
                      value={companyType}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.companyType}
                      // className="input input-item"
                      required
                    />

                    <FormInput
                      label="Quantity"
                      name="quantity"
                      type="number"
                      value={quantity}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.quantity}
                      required
                    />

                    <FormInput
                      label="Address"
                      name="address"
                      type="text"
                      value={address}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.address}
                      // className="input input-item"
                      required
                    />

                    <FormInput
                      label="Zip/Postal"
                      name="postal"
                      type="text"
                      value={postal}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.postal}
                      // className="input input-item"
                      required
                    />

                    <FormInput
                      label="City"
                      name="city"
                      type="text"
                      value={city}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.city}
                      // className="input input-item"
                      required
                    />

                    <FormInput
                      label="State"
                      name="state"
                      type="text"
                      value={state}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.state}
                      // className="input input-item"
                      required
                    />

                    <FormInput
                      label="Country"
                      name="country"
                      type="text"
                      value={country}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.country}
                      // className="input input-item"
                      required
                    />
                    <div className="rular-row">
                      <hr />
                    </div>
                    <FormInput
                      label="Price Per Unit"
                      name="pricePerUnit"
                      type="number"
                      value={pricePerUnit}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.pricePerUnit}
                      required
                    />

                    <FormInput
                      label="QTY Max"
                      name="qtyPrice"
                      type="number"
                      value={qtyPrice}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.qtyPrice}
                      required
                    />

                    <FormInput
                      label="Price"
                      name="price"
                      type="number"
                      value={price}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.price}
                      required
                    />

                    <FormInput
                      label="Quantity"
                      name="quantity"
                      type="number"
                      value={price}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.quantity}
                      required
                    />
                    <div className="percentage-row">
                      <p>25% 50% 75% 100%</p>
                    </div>
                    <FormInput
                      label="Total"
                      name="total"
                      type="number"
                      value={total}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.total}
                      required
                    />

                    <div className="rular-row">
                      <hr />
                    </div>

                    <div className="btn-link">
                      <div className="conditions-container">
                        {this.state.termServiceModalOpen && (
                          <Modal1
                            closeModal={this.handleTermServiceModalStatus}
                            modalWidth="464px"
                            heading="Terms of Service"
                            modalType="Notification"
                          >
                            <div className="modal-body  notification-modal-body">
                              This is an pre-alpha stage product.
                              <br /> All bids and sales are with test ada.{' '}
                              <br /> Please do not send real ada to wallets.
                            </div>
                          </Modal1>
                        )}

                        <input
                          type="checkbox"
                          name="termsConditions"
                          id="termsConditions"
                          className="checkbox"
                        />
                        <span className="terms-onditions-text">
                          I confirm this is compliant with{' '}
                          <span onClick={this.handleTermServiceModalStatus}>
                            terms and conditions
                          </span>
                        </span>
                      </div>
                      {this.state.congratsModalOpen && (
                        <Modal1
                          closeModal={this.handleCongratsModalStatus}
                          modalWidth="464px"
                          modalType="Notification"
                        >
                          <div className="modal-body  notification-modal-body">
                            <h3>Congrats!!</h3>
                            <p>
                              You have successfully accepted a bid
                              <br /> We’ve emailed you a confirmation
                              <br /> If you don’t recieve this email, please
                              contact Customer Service
                            </p>
                          </div>
                        </Modal1>
                      )}
                      <Button
                        type="submit"
                        label="Accept"
                        className="btn-account-accept"
                        handleClick={this.handleCongratsModalStatus}
                      />

                      <Button
                        type="submit"
                        label="Cancel"
                        className="btn-account-cancel"
                        handleClick={this.onSubmit}
                      />
                    </div>
                  </div>
                </Modal1>
              )}

              {this.state.sellingModalOpen && (
                <Modal1 closeModal={this.handleSellingClick} heading="Sell">
                  <div className="modal-body selling-modal-body">
                    <FormInput
                      label="Item"
                      name="item"
                      type="text"
                      value={item}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.quantity}
                      required
                    />

                    <div className="rular-row">
                      <hr />
                    </div>

                    <div className="details">
                      <label>Details</label>
                      <textarea rows="4"></textarea>
                    </div>

                    <FormInput
                      label="Quantity"
                      name="quantity1"
                      type="number"
                      value={quantity1}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.quantity1}
                      // className="input input-item"
                      required
                    />

                    <div className="rular-row">
                      <hr />
                    </div>

                    <FormInput
                      label="Company Name"
                      name="companyName"
                      type="text"
                      value={companyName}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.companyName}
                      // className="input input-item"
                      required
                    />

                    <FormInput
                      label="Company Type"
                      name="companyType"
                      type="text"
                      value={companyType}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.companyType}
                      // className="input input-item"
                      required
                    />

                    <FormInput
                      label="Quantity"
                      name="quantity"
                      type="number"
                      value={quantity}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.quantity}
                      required
                    />

                    <FormInput
                      label="Address"
                      name="address"
                      type="text"
                      value={address}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.address}
                      // className="input input-item"
                      required
                    />

                    <FormInput
                      label="Zip/Postal"
                      name="postal"
                      type="text"
                      value={postal}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.postal}
                      // className="input input-item"
                      required
                    />

                    <FormInput
                      label="City"
                      name="city"
                      type="text"
                      value={city}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.city}
                      // className="input input-item"
                      required
                    />

                    <FormInput
                      label="State"
                      name="state"
                      type="text"
                      value={state}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.state}
                      // className="input input-item"
                      required
                    />

                    <FormInput
                      label="Country"
                      name="country"
                      type="text"
                      value={country}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.country}
                      // className="input input-item"
                      required
                    />
                    <div className="rular-row">
                      <hr />
                    </div>
                    <FormInput
                      label="Price Per Unit"
                      name="pricePerUnit"
                      type="number"
                      value={pricePerUnit}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.pricePerUnit}
                      required
                    />

                    <FormInput
                      label="QTY Max"
                      name="qtyPrice"
                      type="number"
                      value={qtyPrice}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.qtyPrice}
                      required
                    />

                    <FormInput
                      label="Price"
                      name="price"
                      type="number"
                      value={price}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.price}
                      required
                    />

                    <FormInput
                      label="Quantity"
                      name="quantity"
                      type="number"
                      value={price}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.quantity}
                      required
                    />
                    <div className="percentage-row">
                      <p>25% 50% 75% 100%</p>
                    </div>
                    <FormInput
                      label="Total"
                      name="total"
                      type="number"
                      value={total}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.total}
                      required
                    />

                    <div className="rular-row">
                      <hr />
                    </div>

                    <div className="btn-link">
                      <div className="conditions-container">
                        {this.state.termServiceModalOpen && (
                          <Modal1
                            closeModal={this.handleTermServiceModalStatus}
                            modalWidth="464px"
                            heading="Terms of Service"
                            modalType="Notification"
                          >
                            <div className="modal-body  notification-modal-body">
                              This is an pre-alpha stage product.
                              <br /> All bids and sales are with test ada.{' '}
                              <br /> Please do not send real ada to wallets.
                            </div>
                          </Modal1>
                        )}

                        <input
                          type="checkbox"
                          name="termsConditions"
                          id="termsConditions"
                          className="checkbox"
                        />
                        <span className="terms-onditions-text">
                          I confirm this is compliant with{' '}
                          <span onClick={this.handleTermServiceModalStatus}>
                            terms and conditions
                          </span>
                        </span>
                      </div>
                      {this.state.congratsModalOpen && (
                        <Modal1
                          closeModal={this.handleCongratsModalStatus}
                          modalWidth="464px"
                          modalType="Notification"
                        >
                          <div className="modal-body  notification-modal-body">
                            <h3>Congrats!!</h3>
                            <p>
                              You have successfully accepted a bid
                              <br /> We’ve emailed you a confirmation
                              <br /> If you don’t recieve this email, please
                              contact Customer Service
                            </p>
                          </div>
                        </Modal1>
                      )}
                      <Button
                        type="submit"
                        label="Accept"
                        className="btn-account-accept"
                        handleClick={this.handleCongratsModalStatus}
                      />

                      <Button
                        type="submit"
                        label="Cancel"
                        className="btn-account-cancel"
                        handleClick={this.onSubmit}
                      />
                    </div>
                  </div>
                </Modal1>
              )}

              <Button
                handleClick={this.handleStatus}
                type="button"
                label="+ Create New Contract"
                className="add-inventory"
              />

              <Button
                handleClick={this.handleStatus}
                type="button"
                label="+"
                className="add-inventory1"
              />
            </div>
            <div className="content-container">
              <Table
                tableData={DATA_CONTRACTS_TABLE_1}
                headingColumns={[
                  'Item',
                  'Quantity',
                  'Quality',
                  'PerUnit',
                  'Total',
                  'Delivery Date',
                  'Location',
                ]}
                title=""
                tableFor="contracts1"
                breakOn="small"
                handleOnClick={this.handleBuyingClick}
              />
            </div>
            <hr />
            <div style={{ marginBottom: '16px' }} className="heading-container">
              <span className="heading-text">Close Contracts</span>
            </div>
            <div className="content-container">
              <Table
                tableData={DATA_CONTRACTS_TABLE_2}
                headingColumns={[
                  'Item',
                  'Quantity',
                  'Quality',
                  'PerUnit',
                  'Total',
                  'Delivery Date',
                  'Location',
                ]}
                title=""
                tableFor="contracts2"
                breakOn="small"
                handleOnClick={this.handleSellingClick}
              />
            </div>
          </div>
        </div>
      </WithNavbar>
    )
  }
}

export default ContractsPage
