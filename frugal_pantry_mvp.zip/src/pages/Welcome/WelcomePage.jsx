import React from 'react'

import './WelcomePage.scss'
function welcomePage() {
  return (
    <div>
      <section className="welcome-body">
        <p className="welcome-text">Frugal Pantry MVP</p>
      </section>
    </div>
  )
}

export default welcomePage
