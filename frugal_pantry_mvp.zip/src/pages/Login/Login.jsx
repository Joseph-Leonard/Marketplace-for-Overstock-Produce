import React from 'react'
import { Link } from 'react-router-dom'

import Button from '../../components/Button/Button'
// import Navbar from '../../components/Navbar/Navbar'
import FormInput from '../../components/FormInput/FormInput'

// import { DATA_FOR_TESTING } from '../../services/demoData'

import './LoginPage.scss'
class LoginPage extends React.Component {
  state = {
    user: {
      username: '',
      password: '',
    },
    errors: {},
    submitted: false,
  }

  handleChange = event => {
    const { user } = this.state
    user[event.target.name] = event.target.value
    this.setState({ user })
  }

  onSubmit = () => {
    //For now just routing to other page with navbar
    this.props.history.push('/inventory')

    //Here the verification
    const {
      user: { username, password },
    } = this.state
    let err = {}

    if (!username) {
      err.username = 'Enter your username!'
    }

    if (password.length < 8) {
      err.password = 'Password must be at least 8 characters!'
    }

    this.setState({ errors: err }, () => {
      if (Object.getOwnPropertyNames(this.state.errors).length === 0) {
        this.setState({ submitted: true })
      }
    })
  }

  handleSignUp = () => {
    this.props.history.push('/sign-up')
  }

  render() {
    const {
      submitted,
      errors,
      user: { username, password },
    } = this.state
    return (
      <div className="login-form-container">
        <form className="login-form">
          {submitted ? (
            <p className="login-welcome-text">Welcome onboard, {username}!</p>
          ) : (
            <>
              <h3 className="login-text">Log In</h3>
              <FormInput
                label=""
                name="username"
                type="text"
                value={username}
                onChange={this.handleChange}
                placeholder="Username"
                error={errors.username}
                required
                className="input input-item"
              />

              <FormInput
                label=""
                name="password"
                type="password"
                value={password}
                onChange={this.handleChange}
                placeholder="Password"
                error={errors.password}
                className="input input-item"
                required
              />
              <div className="remember input-item">
                <input
                  type="checkbox"
                  name="rememberme"
                  id="checkbox"
                  className="chaeckbox"
                />
                <span className="rememberme-text">Remember me</span>
              </div>

              <Button
                type="submit"
                label="Log In"
                className=" btn btn-login input-item"
                handleClick={this.onSubmit}
              />

              {/* <Link className="route-Link" to="/sign-up">
                  {' '}
                </Link> */}
              <Button
                type="button"
                label="Sign Up"
                className="btn btn-signup input-item"
                handleClick={this.handleSignUp}
              />

              <p className="forgot-password input-item">Forgot password?</p>
            </>
          )}
        </form>
      </div>
    )
  }
}

export default LoginPage
