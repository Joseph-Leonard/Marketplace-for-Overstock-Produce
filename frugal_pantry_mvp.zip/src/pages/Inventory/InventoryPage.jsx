import React, { Component } from 'react'

import { DATA_INVENTORY_TABLE } from '../../services/demoData'
import {
  DATA_ITEM_DROPDOWN,
  DATA_UNIT_DROPDOWN,
  DATA_QUALITY_DROPDOWN,
} from '../../services/demoData'

import WithNavbar from '../../layout/WithNavbar'
import Button from '../../components/Button/Button'
import Table from '../../components/DataTable/Table'
import Modal from '../../components/Modal/Modal1'
import FormInput from '../../components/FormInput1/Forminput1'
import Select from 'react-select'

import './InventoryPage.scss'
export class InventoryPage extends Component {
  state = {
    modalOpen: false,
    termServiceModalOpen: false,
    user: {
      quantity: '',
    },
    errors: {},
    submitted: false,
  }

  handleStatus = () => {
    this.setState({ modalOpen: !this.state.modalOpen })
  }
  handleTermServiceModalStatus = () => {
    this.setState({ termServiceModalOpen: !this.state.termServiceModalOpen })
  }
  handleChange = event => {
    const { user } = this.state
    user[event.target.name] = event.target.value
    this.setState({ user })
  }

  onSubmit = () => {
    const {
      user: { quantity },
    } = this.state
    let err = {}

    if (!quantity) {
      err.quantity = 'Quantity is missing!'
    }

    this.setState({ errors: err }, () => {
      if (Object.getOwnPropertyNames(this.state.errors).length === 0) {
        this.setState({ submitted: true })
      }
    })
  }

  render() {
    const {
      errors,
      user: { quantity },
    } = this.state
    return (
      <WithNavbar>
        <div className="card">
          <div className="card-header">
            <div className="card-title">
              <h3>Invetory</h3>
              <hr />
            </div>
          </div>
          <div className="card-body">
            <div className="heading-container">
              <span className="heading-text">Inventory in Storage</span>
              {this.state.modalOpen && (
                <Modal closeModal={this.handleStatus}>
                  <div className="modal-body inventory-modal-body">
                    <div className="react-select-container">
                      <label className="react-select-label">Item</label>

                      <Select
                        id="item"
                        className="react-select"
                        classNamePrefix="react-select"
                        options={DATA_ITEM_DROPDOWN}
                      />
                    </div>

                    <div className="react-select-container">
                      <label className="react-select-label">Quality</label>

                      <Select
                        id="quality"
                        className="react-select"
                        classNamePrefix="react-select"
                        options={DATA_QUALITY_DROPDOWN}
                      />
                    </div>

                    <FormInput
                      label="Quantity"
                      name="quantity"
                      type="number"
                      value={quantity}
                      onChange={this.handleChange}
                      placeholder=""
                      error={errors.quantity}
                      required
                    />

                    <div className="react-select-container">
                      <label className="react-select-label">Unit</label>

                      <Select
                        id="unit"
                        className="react-select"
                        classNamePrefix="react-select"
                        options={DATA_UNIT_DROPDOWN}
                      />
                    </div>

                    <div className="details">
                      <label>Details</label>
                      <textarea rows="4"></textarea>
                    </div>

                    <div className="btn-link">
                      <div className="conditions-container">
                        {this.state.termServiceModalOpen && (
                          <Modal
                            closeModal={this.handleTermServiceModalStatus}
                            modalWidth="464px"
                            heading="Terms of Service"
                            modalType="Notification"
                          >
                            <div className="modal-body  notification-modal-body">
                              This is an pre-alpha stage product.
                              <br /> All bids and sales are with test ada.{' '}
                              <br /> Please do not send real ada to wallets.
                            </div>
                          </Modal>
                        )}

                        <input
                          type="checkbox"
                          name="termsConditions"
                          id="termsConditions"
                          className="checkbox"
                        />
                        <span className="terms-onditions-text">
                          I confirm this Item is compliant with{' '}
                          <span onClick={this.handleTermServiceModalStatus}>
                            terms and conditions
                          </span>
                        </span>
                      </div>
                      <Button
                        type="submit"
                        label="+ Add Inventory in Storage"
                        className="btn-account-accept"
                        handleClick={this.onSubmit}
                      />
                    </div>
                  </div>
                </Modal>
              )}

              <Button
                handleClick={this.handleStatus}
                type="button"
                label="+ Add Inventory in Storage"
                className="add-inventory"
              />

              <Button
                handleClick={this.handleStatus}
                type="button"
                label="+"
                className="add-inventory1"
              />
            </div>
            <div className="content-container">
              <Table
                tableData={DATA_INVENTORY_TABLE}
                headingColumns={['Item', 'Quantity', 'Quality']}
                title=""
                tableFor="inventory"
                breakOn="small"
              />
            </div>
          </div>
          <div className="card-footer"></div>
        </div>
      </WithNavbar>
    )
  }
}

export default InventoryPage
